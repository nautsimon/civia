// // import * as React from "react";
// // import { View, Text } from "react-native";
// // import { NavigationContainer } from "@react-navigation/native";
// // import { createStackNavigator } from "@react-navigation/stack";

// // function HomeScreen() {
// //   return (
// //     <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
// //       <Text>Home Screen</Text>
// //     </View>
// //   );
// // }

// // const Stack = createStackNavigator();

// // function App() {
// //   return (
// //     <NavigationContainer>
// //       <Stack.Navigator>
// //         <Stack.Screen name="Home" component={HomeScreen} />
// //       </Stack.Navigator>
// //     </NavigationContainer>
// //   );
// // }

// // export default App;

// react-native-vector-icons/Ionicons otherwise.
import * as React from "react";
import { Text, View, StyleSheet } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { NavigationContainer } from "@react-navigation/native";
import Map from "./components/Map";
import Feed from "./components/Feed";
import Home from "./components/Home";

function HomeScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Home />
    </View>
  );
}

function FeedScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Feed />
    </View>
  );
}
function MapScreen() {
  return <Map />;
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer style={styles.bottomCont}>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === "Map") {
              iconName = focused ? "map-outline" : "map-outline";
            } else if (route.name === "Bulletin") {
              iconName = focused ? "bulletin-board" : "bulletin-board";
            } else if (route.name === "Home") {
              iconName = focused ? "home-outline" : "home-outline";
            }

            // You can return any component that you like here!
            return (
              <MaterialCommunityIcons
                name={iconName}
                size={size}
                color={color}
              />
            );
          },
        })}
        tabBarOptions={{
          activeTintColor: "#51a1c0",
          inactiveTintColor: "gray",
        }}
      >
        <Tab.Screen name="Bulletin" component={FeedScreen} />
        <Tab.Screen name="Home" component={HomeScreen} />

        <Tab.Screen name="Map" component={MapScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
const styles = StyleSheet.create({
  bottomCont: {},
});
// import * as React from "react";
// import { Text, View } from "react-native";
// import { NavigationContainer } from "@react-navigation/native";
// import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
// import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
// import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

// function HomeScreen() {
//   return (
//     <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
//       <Text>Home!</Text>
//     </View>
//   );
// }

// function SettingsScreen() {
//   return (
//     <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
//       <Text>Settings!</Text>
//     </View>
//   );
// }

// const Tab = createBottomTabNavigator();

// export default function App() {
//   return (
//     <NavigationContainer>
//       <Tab.Navigator
//         activeColor="#f0edf6"
//         inactiveColor="#3e2465"
//         barStyle={{ paddingBottom: 48 }}
//       >
//         <Tab.Screen name="Bulletin" component={HomeScreen} />
//         <Tab.Screen name="Home" component={SettingsScreen} />
//         <Tab.Screen
//           name="Map"
//           options={{
//             tabBarLabel: "Profile",
//             tabBarIcon: ({ color }) => (
//               <MaterialCommunityIcons name="account" color={color} size={26} />
//             ),
//           }}
//           component={SettingsScreen}
//         />
//       </Tab.Navigator>
//     </NavigationContainer>
//   );
// }
