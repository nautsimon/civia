import React, { Component } from "react";
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Platform,
  Button,
  TextInput,
  Modal,
  Pressable,
  Alert,
} from "react-native";
import * as Location from "expo-location";

export default class Feed extends Component {
  state = {
    lat: null,
    long: null,
    location: "Loading...",
    modalVis: false,
    title: "",
    text: "",
    btnSelected: 0,
    data: [
      {
        postText: "loading...",
        postTitle: "",
        posterId: "",
        tags: "",
      },
    ],
  };
  //https://maps.googleapis.com/maps/api/geocode/json?latlng=40.714224,-73.961452&key=YOUR_API_KEY

  componentDidMount() {
    let getPermissions = () => {
      return Location.requestPermissionsAsync();
    };
    let getPostsReq = () => {
      fetch(
        //   "https://civia-305409.uc.r.appspot.com/getPosts?locationId=Sacramento&sort_on=time&posterId=None&likerId=None&tags=None"
        // )
        "https://civia-305409.uc.r.appspot.com/getPosts?locationId=" +
          this.state.location +
          "&sort_on=time&posterId=None&likerId=None&tags=None"
      )
        .then((response) => response.json())
        .then((outArr) => {
          this.setState({
            data: outArr.data,
          });
        })
        .catch((error) => {
          this.setState({
            location: "fail",
          });
        });
    };
    let updateLocation = () => {
      fetch(
        "https://maps.googleapis.com/maps/api/geocode/json?latlng=" +
          this.state.lat +
          "," +
          this.state.long +
          "&key=AIzaSyDCly_nZeatqxh7J7fTpdvUD-L76rQbSg0&result_type=locality"
      )
        .then((response) => response.json())
        .then((outArr) => {
          this.setState({
            location: outArr.results[0].address_components[0].short_name, //.geometry.location.lat,
          });
        })
        .then(() => {
          getPostsReq();
        })
        .catch((error) => {
          this.setState({
            location: "fail",
          });
        });
    };

    // "https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyDCly_nZeatqxh7J7fTpdvUD-L76rQbSg0&latlng=" +
    //         currLocation.coords.latitude +
    //         "," +
    //         currLocation.coords.longitude +""
    //     );
    getPermissions()
      .then((status) => {
        return Location.getCurrentPositionAsync({});
      })
      .then((currLocation) => {
        this.setState({
          lat: currLocation.coords.latitude,
          long: currLocation.coords.longitude,
        });
      })
      .then((currLocation) => {
        return updateLocation();
      })
      // .then(() => {
      //   getPostsReq();
      // })
      .catch((error) => {
        this.setState({
          location: "failed",
        });
      });
  }
  postNew = () => {
    let makePost = (tag) => {
      fetch(
        //   "https://civia-305409.uc.r.appspot.com/newPost?locationId=Sacramento&postTitle=Test from postman&posterId=postman&postText=Test from postman&tags=Inspiration"
        // )
        "https://civia-305409.uc.r.appspot.com/newPost?locationId=" +
          this.state.location +
          "&postTitle=" +
          this.state.title +
          "&posterId=" +
          "simonm" +
          "&postText=" +
          this.state.text +
          "&tags=" +
          tag
      )
        .then((response) => response.json())
        .then(() => {
          this.setState({
            modalVis: !this.state.modalVis,
          });
        })
        .catch((error) => {
          this.setState({
            modalVis: !this.state.modalVis,
          });
        });
    };
    var tag = "";
    if (this.state.btnSelected === 0) {
      tag = "Inspirational";
    } else if (this.state.btnSelected === 1) {
      tag = "Seeking Help";
    } else if (this.state.btnSelected === 2) {
      tag = "Offering Help";
    } else if (this.state.btnSelected === 3) {
      tag = "Locations";
    }
    makePost(tag);
  };
  populateFeed = () => {
    return this.state.data.map((data) => {
      var bColor = "#51a1c0";
      var bbColor = "#51a1c0";
      if (data.tags == "Inspiration") {
        bColor = "#F7E7A8";
        bbColor = "#87762F";
      } else if (data.tags == "Seeking Help") {
        bColor = "#F7A8A8";
        bbColor = "#A54141";
      } else if (data.tags == "Offering Help") {
        bColor = "#BBA8F7";
        bbColor = "#564299";
      } else if (data.tags == "Locations") {
        bColor = "#D1F7A8";
        bbColor = "#679338";
      } else {
        bColor = "#D1F7A8";
        bbColor = "#679338";
      }
      return (
        <View style={styles.postContainer}>
          <Text style={styles.postTitle}>{data.postTitle}</Text>
          <View style={styles.row}>
            <Text
              style={{
                backgroundColor: bColor,
                alignSelf: "flex-start",
                paddingVertical: 3,
                paddingHorizontal: 8,
                marginBottom: 4,
                marginTop: 4,
                borderRadius: 10,
                overflow: "hidden",
                color: bbColor,
                fontSize: 14,
              }}
            >
              {data.tags}
            </Text>
            <Text style={styles.postAuthor}>@{data.posterId}</Text>
          </View>
          <Text style={styles.postText}> {data.postText}</Text>
        </View>
      );
    });
    // this.state.data.map((post) => {
    //   return (
    //     <View>
    //       <View style={styles.postTags}>
    //         <Text>joe</Text>
    //       </View>
    //       <View style={styles.postAuthor}>
    //         <Text>joe</Text>
    //       </View>
    //       <View>
    //         <Text style={styles.postText}>joe</Text>
    //       </View>
    //     </View>
    //   );
    // });
  };

  render() {
    return (
      <View style={styles.container}>
        <Modal
          animationType="slide"
          transparent={true}
          visible={this.state.modalVis}
          onRequestClose={() => {
            this.setState({ modalVis: !this.state.modalVis });
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={{ fontSize: 20, marginBottom: 20 }}>
                Compose a Bulletin Post
              </Text>
              <TextInput
                style={{
                  height: 40,
                  alignSelf: "stretch",
                  borderBottomWidth: 1,
                  borderBottomColor: "grey",
                }}
                placeholder="Post Title"
                onChangeText={(title) => this.setState({ title: title })}
                defaultValue={this.state.title}
              />
              <Text style={{ fontSize: 15, marginBottom: 10, marginTop: 30 }}>
                Please select a related tag.
              </Text>

              <ScrollView
                horizontal={true}
                showsHorizontalScrollIndicator={false}
                style={{ maxHeight: 70 }}
              >
                <Text
                  style={
                    this.state.btnSelected == 0
                      ? styles.btnSelected
                      : styles.notSelected
                  }
                  onPress={() => this.setState({ btnSelected: 0 })}
                >
                  Offering Help
                </Text>
                <Text
                  style={
                    this.state.btnSelected == 1
                      ? styles.btnSelected
                      : styles.notSelected
                  }
                  onPress={() => this.setState({ btnSelected: 1 })}
                >
                  Seeking Help
                </Text>
                <Text
                  style={
                    this.state.btnSelected == 2
                      ? styles.btnSelected
                      : styles.notSelected
                  }
                  onPress={() => this.setState({ btnSelected: 2 })}
                >
                  Inspiration
                </Text>
                <Text
                  style={
                    this.state.btnSelected == 3
                      ? styles.btnSelected
                      : styles.notSelected
                  }
                  onPress={() => this.setState({ btnSelected: 3 })}
                >
                  Locations
                </Text>
              </ScrollView>

              <TextInput
                multiline={true}
                style={{
                  height: 90,
                  marginTop: 0,
                  marginBottom: 20,
                  alignSelf: "stretch",
                  borderBottomWidth: 1,
                  borderBottomColor: "grey",
                }}
                placeholder="Post body"
                onChangeText={(text) => this.setState({ text: text })}
                defaultValue={this.state.text}
              />

              <View style={styles.rowC}>
                <Pressable
                  style={[styles.button, styles.buttonClose]}
                  onPress={() =>
                    this.setState({ modalVis: !this.state.modalVis })
                  }
                >
                  <Text style={styles.textStyle}>Cancel</Text>
                </Pressable>
                <Pressable
                  style={[styles.button, styles.buttonClose]}
                  onPress={() => this.postNew()}
                >
                  <Text style={styles.textStyle}>Post</Text>
                </Pressable>
              </View>
            </View>
          </View>
        </Modal>
        <View style={styles.topBar}>
          <Text style={styles.locationText}>{this.state.location}'s</Text>
          <Text style={styles.locationSubText}>Bulletin Board</Text>
        </View>

        <ScrollView style={styles.feed}>{this.populateFeed()}</ScrollView>
        <View style={styles.newPost}>
          <Text
            onPress={() => this.setState({ modalVis: true })}
            style={styles.newPostButton}
          >
            +
          </Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    alignSelf: "stretch",

    flex: 1,
    justifyContent: "center",
  },
  locationText: {
    fontSize: 18,
    marginTop: 55,
    paddingBottom: 5,
    textAlign: "center",
    color: "#51a1c0",
  },
  locationSubText: {
    fontSize: 25,
    paddingTop: -3,
    paddingBottom: 15,
    textAlign: "center",
  },
  topBar: {
    backgroundColor: "white",
    alignSelf: "stretch",
    textAlign: "center",
    borderBottomColor: "#D9EBF2",
    borderBottomWidth: 2,
  },
  feed: {
    backgroundColor: "#ffffff",
  },
  postTags: {
    alignSelf: "flex-start",
    paddingVertical: 3,
    paddingHorizontal: 8,
    marginBottom: 4,
    borderRadius: 10,
    overflow: "hidden",
    color: "white",
    fontSize: 14,
  },
  btnSelected: {
    alignSelf: "flex-start",
    paddingVertical: 3,
    paddingHorizontal: 8,
    marginBottom: 4,
    borderRadius: 10,
    overflow: "hidden",
    color: "white",
    fontSize: 14,
    borderColor: "#51a1c0",
    borderWidth: 2,
    backgroundColor: "#51a1c0",
    marginRight: 5,
  },
  notSelected: {
    alignSelf: "flex-start",
    paddingVertical: 3,
    paddingHorizontal: 8,
    marginBottom: 4,
    borderRadius: 10,
    overflow: "hidden",
    color: "#51a1c0",
    fontSize: 14,
    borderColor: "#51a1c0",
    borderWidth: 2,
    backgroundColor: "white",
    marginRight: 5,
  },
  postAuthor: {
    fontSize: 15,
    color: "grey",
    paddingBottom: 4,
    marginLeft: 5,
  },
  postContainer: {
    paddingHorizontal: 15,
    paddingVertical: 20,
    borderBottomColor: "#C9C9C9",
    borderBottomWidth: 1,
  },
  postTitle: { fontSize: 20, fontWeight: "bold" },
  row: {
    flexDirection: "row",
    alignItems: "center",
  },
  rowC: {
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
    justifyContent: "center",
  },
  newPost: {
    position: "absolute",
    alignSelf: "flex-end",
    paddingVertical: 5,
    paddingHorizontal: 5,
    borderRadius: 30,
    borderColor: "#51a1c0",
    borderWidth: 2,
    overflow: "hidden",
    backgroundColor: "white",
    bottom: 7,
    right: 7,
  },
  newPostButton: {
    color: "#51a1c0",
    paddingHorizontal: 11,
    textAlignVertical: "center",
    fontSize: 40,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
  },
  postText: {
    marginTop: 5,
  },
  modalView: {
    margin: 10,
    backgroundColor: "white",
    borderRadius: 20,
    paddingHorizontal: 35,
    paddingVertical: 80,
    alignItems: "flex-start",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    width: 90,
    padding: 10,
    elevation: 2,
    marginHorizontal: 8,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    borderColor: "#51a1c0",
    borderWidth: 2,
    backgroundColor: "white",
    color: "#51a1c0",
  },
  textStyle: {
    color: "#51a1c0",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
});

AppRegistry.registerComponent("Feed", () => Feed);
