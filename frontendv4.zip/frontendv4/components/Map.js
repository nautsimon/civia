import React, { Component } from "react";
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Platform,
  Button,
  Alert,
} from "react-native";
import * as Location from "expo-location";
import MapView from "react-native-maps";

export default class testCoords extends Component {
  state = {
    btnSelected: 0,
    mapRegion: null,
    lastLat: null,
    lastLong: null,
    resp: "nonne",
    markers: [],
  };

  componentDidMount() {
    let getPermissions = () => {
      return Location.requestPermissionsAsync();
    };
    getPermissions()
      .then((status) => {
        return Location.getCurrentPositionAsync({});
      })
      .then((currLocation) => {
        return {
          latitude: parseFloat(currLocation.coords.latitude),
          longitude: parseFloat(currLocation.coords.longitude),
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        };
      })
      .then((currLocation) => {
        this.setState({
          mapRegion: currLocation,
          lastLat: currLocation.latitude,
          lastLong: currLocation.longitude,
          resp: "joe", //.geometry.location.lat,
        });
      })
      .catch((error) => {
        this.setState({
          resp: "fail",
        });
      });

    // this.watchID = navigator.geolocation.watchPosition(
    //   (position) => {
    //     let region = {
    //       latitude: parseFloat(position.coords.latitude),
    //       longitude: parseFloat(position.coords.longitude),
    //       latitudeDelta: 0.00002,
    //       longitudeDelta: 0.0002,
    //     };
    //     this.onRegionChange(region, region.latitude, region.longitude);
    //   },
    //   (error) => console.log(error),
    //   {
    //     enableHighAccuracy: true,
    //     timeout: 20000,
    //     maximumAge: 1000,
    //   }
    // );
  }

  handleQuery(buttonNum, query) {
    // let updateButton = (buttonNum) => {
    //   return new Promise((resolve, reject) => {
    //     this.setState({ btnSelected: buttonNum });
    //   });
    // };
    // let updateButton3 = () => {
    //   return new Promise((resolve, reject) => {
    //     this.setState({ resp: "joe" });
    //   });
    // };
    // let getData = (query) => {
    //   return fetch(
    //     "https://maps.googleapis.com/maps/api/place/textsearch/json?key=AIzaSyDCly_nZeatqxh7J7fTpdvUD-L76rQbSg0&query=publicbathroom&radius=10000&location=41.7948 -87.5917"
    //   )
    //     .then((response) => response.json())
    //     .then((responseJson) => {
    //       return new Promise((resolve, reject) => {
    //         this.setState({ resp: query });
    //       });
    //     })
    //     .catch((error) => {
    //       return new Promise((resolve, reject) => {
    //         this.setState({ resp: query });
    //       });
    //     });
    //   // return new Promise((resolve, reject) => {
    //   //   fetch(
    //   //     "https://maps.googleapis.com/maps/api/place/textsearch/json?key=AIzaSyDCly_nZeatqxh7J7fTpdvUD-L76rQbSg0&query=publicbathroom&radius=10000&location=41.7948 -87.5917"
    //   //   ).then((response) => {
    //   //     return new Promise((resolve, reject) => {
    //   //       this.setState({ resp: query });
    //   //     });
    //   //   });
    //   // });
    // };
    let getData = (locations) => {
      var output = [];
      for (var i = 0; i < locations.length; i++) {
        output.push({
          lat: locations[i].geometry.location.lat,
          long: locations[i].geometry.location.lng,
          name: locations[i].name,
          // id: locations[i].place_id,
          // rating: locations[i].rating,
        });
      }
      return output;
    };
    fetch(
      "https://maps.googleapis.com/maps/api/place/textsearch/json?key=AIzaSyDCly_nZeatqxh7J7fTpdvUD-L76rQbSg0&query=" +
        query +
        "&radius=5000&location=" +
        this.state.mapRegion.latitude.toString() +
        " " +
        this.state.mapRegion.longitude.toString()
    )
      .then((response) => response.json())
      .then((responseJson) => {
        return getData(responseJson.results);
      })
      .then((outArr) => {
        this.setState({
          resp: outArr[0].lng, //.geometry.location.lat,
          markers: outArr, //.geometry.location.lat,
          btnSelected: buttonNum,
        });
      })
      .catch((error) => {
        this.setState({
          resp: "fail",
          btnSelected: buttonNum,
        });
      });

    // updateButton(buttonNum)
    //   .then(() => {
    //     return updateButton3();
    //   })
    //   // .then((responseJson) => {
    //   //   return responseJson.movies;
    //   // })
    //   .catch((error) => {
    //     return updateButton3();
    //   });

    // return updateButton(buttonNum)
    // .then(() => {
    //   return this.setState({
    //     message: "Searching Complete",
    //     current: "",
    //     disabled: false,
    //   })
    //   .catch((error) => {
    //     console.error(error);
    //   });
    // updateButton(buttonNum)
    //   .then(() => {
    //     return new Promise((resolve, reject) => {
    //       this.setState({ resp: "joe" });
    //     });
    //   })
    //   .then(() => {
    //     return new Promise((resolve, reject) => {
    //       this.setState({ resp: "joe" });
    //     });
    //   });
  }
  mapMarkers = () => {
    return this.state.markers.map((report) => (
      <MapView.Marker
        // key={report.id}
        coordinate={{ latitude: report.lat, longitude: report.long }}
        title={report.name}
        image={require("../assets/smallLoc.png")}
        // description={report.rating}
      ></MapView.Marker>
    ));
  };
  //   onRegionChange(region, lastLat, lastLong) {
  //     this.setState({
  //       mapRegion: region,
  //       // If there are no new values set use the the current ones
  //       lastLat: lastLat || this.state.lastLat,
  //       lastLong: lastLong || this.state.lastLong,
  //     });
  //   }

  //   componentWillUnmount() {
  //     navigator.geolocation.clearWatch(this.watchID);
  //   }
  render() {
    return (
      <View style={{ flex: 1 }}>
        <MapView
          style={styles.map}
          region={this.state.mapRegion}
          showsUserLocation={true}
        >
          {/* <MapView.Marker
            coordinate={{
              latitude: this.state.lastLat + 0.0005 || -36.82339,
              longitude: this.state.lastLong + 0.0005 || -73.03569,
            }}
          >
            <View>
              <Text style={{ color: "#000" }}>
                {this.state.lastLong} / {this.state.lastLat}
              </Text>
            </View>
          </MapView.Marker> */}
          {this.mapMarkers()}
        </MapView>
        {/* <Button
          title="Press me"
          onPress={() => Alert.alert("Simple Button pressed")}
        /> */}
        <View style={styles.topBar}>
          <View style={styles.topSubtitle}>
            <Text style={styles.topSubtitleTxt}>What are you looking for?</Text>
          </View>
          <View style={styles.scrollViewHolder}>
            <ScrollView
              horizontal={true}
              showsHorizontalScrollIndicator={false}
            >
              <Text
                style={
                  this.state.btnSelected == 1
                    ? styles.btnSelected
                    : styles.notSelected
                }
                onPress={() => this.handleQuery(1, "public bathroom")}
              >
                Bathroom
              </Text>
              <Text
                style={
                  this.state.btnSelected == 2
                    ? styles.btnSelected
                    : styles.notSelected
                }
                onPress={() => this.handleQuery(2, "drinking water fountain")}
              >
                Water
              </Text>
              <Text
                style={
                  this.state.btnSelected == 3
                    ? styles.btnSelected
                    : styles.notSelected
                }
                onPress={() => this.handleQuery(3, "food bank")}
              >
                Food
              </Text>
              <Text
                style={
                  this.state.btnSelected == 4
                    ? styles.btnSelected
                    : styles.notSelected
                }
                onPress={() => this.handleQuery(4, "cheap inns")}
              >
                Somewhere to sleep
              </Text>
              <Text
                style={
                  this.state.btnSelected == 5
                    ? styles.btnSelected
                    : styles.notSelected
                }
                onPress={() => this.handleQuery(5, "rehab")}
              >
                Rehab
              </Text>
            </ScrollView>
            {/* <Text>{this.state.resp}</Text> */}
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  container: {
    paddingTop: Platform.OS === "ios" ? 20 : 0,
    flex: 1,
    justifyContent: "center",
  },

  scrollViewHolder: { justifyContent: "center" },
  topBar: { backgroundColor: "#ffffff", justifyContent: "center" },
  topSubtitleTxt: {
    fontSize: 18,
    paddingTop: 70,
    paddingBottom: 5,
    textAlign: "center",
    color: "#51a1c0",
    fontWeight: "bold",
  },
  btnSelected: {
    paddingTop: 10,
    paddingBottom: 10,
    paddingRight: 15,
    paddingLeft: 15,
    marginLeft: 4,
    marginRight: 4,
    marginTop: 4,
    marginBottom: 18,
    borderRadius: 20,
    overflow: "hidden",
    color: "white",
    fontSize: 18,
    backgroundColor: "#51a1c0",
    borderColor: "#51a1c0",
    borderWidth: 2,
  },
  notSelected: {
    paddingTop: 10,
    paddingBottom: 10,
    paddingRight: 15,
    paddingLeft: 15,
    marginLeft: 4,
    marginRight: 4,
    marginTop: 4,
    marginBottom: 18,
    borderRadius: 20,
    overflow: "hidden",
    color: "#51a1c0",
    fontSize: 18,
    backgroundColor: "white",
    borderColor: "#51a1c0",
    borderWidth: 2,
  },

  separator: {
    width: 2,
    backgroundColor: "rgba(57, 176, 232, 1)",
  },
});

AppRegistry.registerComponent("testCoords", () => testCoords);
