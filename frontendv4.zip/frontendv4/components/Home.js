import React, { Component } from "react";
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Platform,
  Button,
  TextInput,
  FlatList,
  Pressable,
  Image,
} from "react-native";
import * as Location from "expo-location";
import icon from "../assets/shorterCC.png";
// import ForecastCard from "./Foreskin";
import { Card, Divider } from "react-native-elements";

export default class Home extends Component {
  state = {
    lat: null,
    long: null,
    location: "Loading...",
    modalVis: false,
    title: "",
    text: "",
    btnSelected: 0,
    forecast: [
      {
        weather: [{ icon: "", description: "" }],
        temp: { day: "" },
      },
      {
        weather: [{ icon: "", description: "" }],
        temp: { day: "" },
      },
    ],
  };
  //https://maps.googleapis.com/maps/api/geocode/json?latlng=40.714224,-73.961452&key=YOUR_API_KEY

  componentDidMount() {
    let getPermissions = () => {
      return Location.requestPermissionsAsync();
    };

    let getWeather = () => {
      // Construct the API url to call
      let url =
        "https://api.openweathermap.org/data/2.5/forecast?lat=" +
        this.state.lat +
        "&lon=" +
        this.state.long +
        "&units=metric&appid=7f35160c8f690e08983909704c4876e3";
      // Call the API, and set the state of the weather forecast
      fetch(
        "https://api.openweathermap.org/data/2.5/onecall?lat=38.5816&lon=-121.4944&units=metric&appid=7f35160c8f690e08983909704c4876e3"
      )
        .then((response) => response.json())
        .then((data) => {
          this.setState((prevState, props) => ({
            forecast: data.daily,
          }));
        });
    };
    let updateLocation = () => {
      fetch(
        "https://maps.googleapis.com/maps/api/geocode/json?latlng=" +
          this.state.lat +
          "," +
          this.state.long +
          "&key=AIzaSyDCly_nZeatqxh7J7fTpdvUD-L76rQbSg0&result_type=locality"
      )
        .then((response) => response.json())
        .then((outArr) => {
          this.setState({
            location: outArr.results[0].address_components[0].short_name, //.geometry.location.lat,
          });
        })

        .catch((error) => {
          this.setState({
            location: "fail",
          });
        });
    };

    // "https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyDCly_nZeatqxh7J7fTpdvUD-L76rQbSg0&latlng=" +
    //         currLocation.coords.latitude +
    //         "," +
    //         currLocation.coords.longitude +""
    //     );
    getPermissions()
      .then((status) => {
        return Location.getCurrentPositionAsync({});
      })
      .then((currLocation) => {
        this.setState({
          lat: currLocation.coords.latitude,
          long: currLocation.coords.longitude,
        });
      })
      .then(() => {
        getWeather();
      })
      .then((currLocation) => {
        return updateLocation();
      })
      // .then(() => {
      //   getPostsReq();
      // })
      .catch((error) => {
        this.setState({
          location: "failed",
        });
      });
  }

  populateFeed = () => {
    return this.state.data.map((data) => {
      var bColor = "#0075A4";
      var bbColor = "#0075A4";
      if (data.tags == "Inspiration") {
        bColor = "#F7E7A8";
        bbColor = "#87762F";
      } else if (data.tags == "Seeking Help") {
        bColor = "#F7A8A8";
        bbColor = "#A54141";
      } else if (data.tags == "Offering Help") {
        bColor = "#BBA8F7";
        bbColor = "#564299";
      } else if (data.tags == "Locations") {
        bColor = "#D1F7A8";
        bbColor = "#679338";
      }
      return (
        <View style={styles.postContainer}>
          <Text style={styles.postTitle}>{data.postTitle}</Text>
          <View style={styles.row}>
            <Text
              style={{
                backgroundColor: bColor,
                alignSelf: "flex-start",
                paddingVertical: 3,
                paddingHorizontal: 8,
                marginBottom: 4,
                marginTop: 4,
                borderRadius: 10,
                overflow: "hidden",
                color: bbColor,
                fontSize: 14,
              }}
            >
              {data.tags}
            </Text>
            <Text style={styles.postAuthor}>@{data.posterId}</Text>
          </View>
          <Text style={styles.postText}> {data.postText}</Text>
        </View>
      );
    });
    // this.state.data.map((post) => {
    //   return (
    //     <View>
    //       <View style={styles.postTags}>
    //         <Text>joe</Text>
    //       </View>
    //       <View style={styles.postAuthor}>
    //         <Text>joe</Text>
    //       </View>
    //       <View>
    //         <Text style={styles.postText}>joe</Text>
    //       </View>
    //     </View>
    //   );
    // });
  };

  render() {
    return (
      <View style={styles.container}>
        <Image
          source={icon}
          style={{
            flex: 1,
            width: 300,
            height: 300,
            top: 50,
            position: "absolute",
            resizeMode: "contain",
          }}
        />

        <Text
          style={{
            fontSize: 30,
            paddingTop: 300,

            position: "absolute",
            left: 20,
          }}
        >
          Hello Simonm!
        </Text>
        <Text
          style={{
            fontSize: 14,
            paddingTop: 340,
            color: "#51a1c0",
            position: "absolute",
            left: 20,
          }}
        >
          Here's the {this.state.location} weather for the next two days...
        </Text>
        <View
          style={{
            paddingTop: 390,

            position: "absolute",
            left: 20,
          }}
        >
          <ScrollView horizontal={false} showsHorizontalScrollIndicator={false}>
            <Card containerStyle={styles.card}>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Text style={styles.time}>
                  {Math.round(this.state.forecast[0].temp.day * 10) / 10}
                  &#8451;
                </Text>
                <Image
                  style={{ width: 100, height: 100 }}
                  source={{
                    uri:
                      "https://openweathermap.org/img/w/" +
                      this.state.forecast[0].weather[0].icon +
                      ".png",
                  }}
                />
              </View>

              <Text style={styles.notes}>
                {this.state.forecast[0].weather[0].description}
              </Text>
            </Card>
            <Card containerStyle={styles.card}>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Text style={styles.time}>
                  {Math.round(this.state.forecast[1].temp.day * 10) / 10}
                  &#8451;
                </Text>
                <Image
                  style={{ width: 100, height: 100 }}
                  source={{
                    uri:
                      "https://openweathermap.org/img/w/" +
                      this.state.forecast[1].weather[0].icon +
                      ".png",
                  }}
                />
              </View>

              <Text style={styles.notes}>
                {this.state.forecast[1].weather[0].description}
              </Text>
            </Card>
          </ScrollView>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  card: {
    backgroundColor: "#51a1c0",
    borderWidth: 0,
    borderRadius: 20,
    width: 350,
    alignSelf: "stretch",
    alignItems: "center",
  },
  time: {
    fontSize: 30,
    color: "#fff",
  },
  notes: {
    fontSize: 18,
    color: "#fff",
    textTransform: "capitalize",
  },
});

AppRegistry.registerComponent("Home", () => Home);
