// "_id": get_latest_id("post") + 1,
// "postText": postInfo["postText"],
// "posterId":  postInfo["posterId"],
// "time": postInfo["time"],
// "tags": [],
// "likes": 0,
// "likers": [],
// "dislikers": [],
// "replies": []
// }
export default data;
